import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { all, get } from "@/lib/db";
import { Card, PageHeader, Badge, Label, inputClass } from "@/components/ui";
import { guardarConfigEmailAction, actualizarAlertasEmailAction } from "@/lib/actions/configuracion";

export default async function ConfiguracionPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  // Solo admin y consejo directivo pueden acceder
  if (!["admin", "consejo_directivo"].includes(user.rol)) {
    redirect("/dashboard");
  }

  const config = all<any>(`SELECT * FROM config_email`);
  const configObj = Object.fromEntries(config.map((c: any) => [c.clave, c.valor]));

  const alertasEmail = all<any>(
    `SELECT ae.*, u.nombre as usuario_nombre FROM alertas_email ae
     LEFT JOIN users u ON u.id = ae.usuario_id
     ORDER BY ae.rol ASC`
  );

  return (
    <div>
      <PageHeader title="Configuración" subtitle="Email, alertas y preferencias del sistema" />

      <h3 className="text-sm font-bold text-[#123240] mb-3">Configuración de Email</h3>
      <Card className="mb-6">
        <p className="text-xs text-black/60 mb-4">
          Configura el servidor SMTP para enviar alertas automáticas. Dejalos en blanco para desactivar email.
        </p>
        <form action={guardarConfigEmailAction} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <Label>Host SMTP</Label>
            <input
              type="text"
              name="smtp_host"
              defaultValue={configObj.smtp_host || ""}
              placeholder="ej: smtp.gmail.com"
              className={inputClass}
            />
          </div>
          <div>
            <Label>Puerto</Label>
            <input
              type="number"
              name="smtp_port"
              defaultValue={configObj.smtp_port || "587"}
              className={inputClass}
            />
          </div>
          <div>
            <Label>Usuario (email)</Label>
            <input
              type="email"
              name="smtp_user"
              defaultValue={configObj.smtp_user || ""}
              placeholder="tu@ejemplo.com"
              className={inputClass}
            />
          </div>
          <div>
            <Label>Contraseña</Label>
            <input
              type="password"
              name="smtp_password"
              placeholder="Contraseña o token de app"
              className={inputClass}
            />
          </div>
          <div className="sm:col-span-2">
            <Label>Remitente (nombre)</Label>
            <input
              type="text"
              name="email_remitente"
              defaultValue={configObj.email_remitente || "UFAMA Sistema"}
              className={inputClass}
            />
          </div>
          <div className="sm:col-span-2">
            <Label>Email de destino para alertas críticas</Label>
            <input
              type="email"
              name="email_alertas_criticas"
              defaultValue={configObj.email_alertas_criticas || ""}
              placeholder="admin@ufama.uy"
              className={inputClass}
            />
          </div>
          <button type="submit" className="sm:col-span-2 rounded-xl bg-[#1f4e5f] text-white px-4 py-2 text-sm font-semibold">
            Guardar configuración
          </button>
        </form>
        <div className="mt-4 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
          <p className="text-xs text-yellow-800">
            <strong>Para Gmail:</strong> Usa contraseña de aplicación (no la contraseña normal). Activa "Acceso de aplicaciones menos seguras" o genera una contraseña de app en tu cuenta Google.
          </p>
        </div>
      </Card>

      <h3 className="text-sm font-bold text-[#123240] mb-3">Alertas por Email</h3>
      <Card className="mb-6">
        <p className="text-xs text-black/60 mb-4">
          Configura qué alertas se envían por email automáticamente.
        </p>
        <form action={actualizarAlertasEmailAction} className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="checkbox" name="tarea_atrasada" defaultChecked={true} />
              Tareas atrasadas
            </label>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="checkbox" name="documento_vencido" defaultChecked={true} />
              Documentos vencidos
            </label>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="checkbox" name="dinero_bajo" defaultChecked={true} />
              Saldo bajo
            </label>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="checkbox" name="problema_critico" defaultChecked={true} />
              Problemas críticos
            </label>
          </div>
          <button type="submit" className="rounded-xl bg-[#1f4e5f] text-white px-4 py-2 text-sm font-semibold">
            Actualizar preferencias
          </button>
        </form>
      </Card>

      <h3 className="text-sm font-bold text-[#123240] mb-3">Info del sistema</h3>
      <Card>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-black/60">Versión:</span>
            <span className="font-semibold">MVP 1.0</span>
          </div>
          <div className="flex justify-between">
            <span className="text-black/60">Base de datos:</span>
            <span className="font-semibold">SQLite (local)</span>
          </div>
          <div className="flex justify-between">
            <span className="text-black/60">Usuarios activos:</span>
            <span className="font-semibold">{all<any>(`SELECT COUNT(*) as c FROM users WHERE activo = 1`)[0].c}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-black/60">Email configurado:</span>
            <Badge color={configObj.smtp_host ? "verde" : "amarillo"}>
              {configObj.smtp_host ? "Sí" : "No"}
            </Badge>
          </div>
        </div>
      </Card>
    </div>
  );
}
